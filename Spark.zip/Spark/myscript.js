var button = document.getElementById('myButton');
var button1 = document.getElementById('sButton');
var button2 = document.getElementById('mButton');
var modal = document.getElementById('myModal');
var close = document.getElementById('myClose');
var content = document.getElementById('myContent');
var plu1 = document.getElementById('myPlu1');
var plu2 = document.getElementById('myPlu2');
var plu3 = document.getElementById('myPlu3');
var plu4 = document.getElementById('myPlu4');
var block = document.getElementById('block');
var rec = document.getElementById('rectangle');
var r1 = document.getElementById('r1');
var c = document.querySelector('#shest001');
var d = document.querySelector('#shest002');
var e = document.querySelector('#shest003');
var f = document.querySelector('#shest004');

function opacity1() {
    content.style.opacity = "1";
}

button.onclick = function() {
    modal.style.display = "block";
    setTimeout(opacity1, 100);
}

function none() {
    modal.style.display = "none";
}

close.onclick = function() {
    content.style.opacity = "0";
    setTimeout(none, 1000);
}

plu1.onclick =function(){
    rectangle.style.display='none';
    r1.style.display='block';
}
plu2.onclick =function(){
    rectangle.style.display='none';
    r2.style.display='block';
}
plu3.onclick =function(){
    rectangle.style.display='none';
    r3.style.display='block';
}
plu4.onclick =function(){
    rectangle.style.display='none';
    r4.style.display='block';
}

c.onclick = function() {
 alert( 'Чекбокс выключён' );
 if (c.checked) {
  alert( 'Условия принимаю' );
 }
}

d.onclick = function() {
    alert( 'Чекбокс выключён' );
    if (d.checked) {
     alert( 'Условия принимаю' );
    }
   }
e.onclick = function() {
    alert( 'Чекбокс выключён' );
    if (e.checked) {
     alert( 'Условия принимаю' );
    }
   } 
f.onclick = function() {
    alert( 'Чекбокс выключён' );
    if (f.checked) {
     alert( 'Условия принимаю' );
    }
   }